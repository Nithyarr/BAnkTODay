﻿using BankModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankServices
{
    public class CustomerService
    {
        private readonly BankDBEntities db;

        public CustomerService()
        {
            db = new BankDBEntities();
        }

            public Savings_Account GetAccountById(int accountId)
            {
                return db.Savings_Account.FirstOrDefault(a => a.ID == accountId);
            }

            public Savings_Account GetSavingsAccount(int customerId)
            {
                return db.Savings_Account.FirstOrDefault(a => a.C_ID == customerId);
            }

            public string Deposit(int accountId, decimal amount)
            {
                var account = GetAccountById(accountId);
                if (account == null) return "No savings account found.";
                if (amount <= 0) return "Deposit amount must be greater than zero.";

                account.BALANCE += amount;

                var txn = new Savings_Transaction
                {
                    ST_ACCOUNT_ID = account.ID,
                    ST_AMOUNT = amount,
                    ST_DEPOSIT = amount,
                    ST_WITHDRAWL = 0,
                    ST_TRANSACTION_DATE = DateTime.Now
                };

                db.Savings_Transaction.Add(txn);
                db.SaveChanges();

                return $"Deposit of ₹{amount} successful. Current balance: ₹{account.BALANCE}";
            }

            public string Withdraw(int accountId, decimal amount)
            {
                var account = GetAccountById(accountId);
                if (account == null) return "No savings account found.";
                if (amount <= 0) return "Withdrawal amount must be greater than zero.";
                if (amount > account.BALANCE) return "Insufficient balance.";

                account.BALANCE -= amount;

                var txn = new Savings_Transaction
                {
                    ST_ACCOUNT_ID = account.ID,
                    ST_AMOUNT = amount,
                    ST_DEPOSIT = 0,
                    ST_WITHDRAWL = amount,
                    ST_TRANSACTION_DATE = DateTime.Now
                };

                db.Savings_Transaction.Add(txn);
                db.SaveChanges();

                return $"Withdrawal of ₹{amount} successful. Current balance: ₹{account.BALANCE}";
            }

            public List<Savings_Transaction> GetTransactions(int accountId)
            {
                return db.Savings_Transaction
                         .Where(t => t.ST_ACCOUNT_ID == accountId)
                         .OrderByDescending(t => t.ST_TRANSACTION_DATE)
                         .Take(10)
                         .ToList();
            }

            public decimal GetBalance(int accountId)
            {
                var account = GetAccountById(accountId);
                return account?.BALANCE ?? 0;
            }
        }
    }

