﻿using BankModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class ManagerController : Controller
    {
        private readonly AuthService dc = new AuthService();
        private readonly BankDBEntities db1 = new BankDBEntities();
        private readonly ManagerService db;

        public ManagerController()
        {
            db1 = new BankDBEntities();
            dc = new AuthService();
            db = new ManagerService(db1); // Pass the context to ManagerService
        }

        public ActionResult ManagerHome()
        {
            ViewBag.Message = $"Welcome Manager {Session["Username"]}";
            return View();
        }
        // GET: OpenAccount page (enter PAN)
        [HttpGet]
        public ActionResult OpenAccount()
        {
            return View();
        }

        // POST: OpenAccount - check PAN
        [HttpPost]
        public ActionResult OpenAccount(string pan)
        {
            if (string.IsNullOrWhiteSpace(pan))
            {
                ViewBag.Message = "Please enter a PAN number.";
                return View();
            }

            var customer = db1.Customers.FirstOrDefault(c => c.C_PAN == pan);

            if (customer != null)
            {
                // Customer exists — show details + option to add account
                ViewBag.Customer = customer;
                Session["CustomerID"] = customer.ID; // Store customer ID in session for account linking

                // Show customer details view (or reuse OpenAccount view but with customer info and add account form)
                return View("CustomerDetails", customer);
            }
            else
            {
                // Customer not found — store PAN in TempData to use in registration
                TempData["PanNumber"] = pan;
                return RedirectToAction("Register", "Home"); // Your existing register action
            }
        }

        // GET: CreateSavingsAccount (for existing customer)
        [HttpGet]
        public ActionResult CreateSavingsAccount()
        {
            if (Session["CustomerID"] == null)
            {
                TempData["ErrorMessage"] = "No customer selected. Please check PAN first.";
                return RedirectToAction("OpenAccount");
            }

            int customerId = (int)Session["CustomerID"];
            ViewBag.Customer = db1.Customers.Find(customerId);

            return View();  // View with form to enter initial balance
        }

        // POST: CreateSavingsAccount - create savings account linked to customer
        [HttpPost]
        public ActionResult CreateSavingsAccount(decimal initialBalance)
        {
            if (Session["CustomerID"] == null)
            {
                TempData["ErrorMessage"] = "No customer selected. Please check PAN first.";
                return RedirectToAction("OpenAccount");
            }

            int customerId = (int)Session["CustomerID"];

            if (initialBalance < 1000) // Assuming minimum balance constraint
            {
                TempData["ErrorMessage"] = "Initial balance must be at least 1000.";
                return RedirectToAction("CreateSavingsAccount");
            }

            // Create savings account
            var savingsAccount = new Savings_Account
            {
                C_ID = customerId,
                BALANCE = initialBalance,
                // CREATED_DATE will default to GETDATE() in DB
            };

            db1.Savings_Account.Add(savingsAccount);
            db1.SaveChanges();

            TempData["SuccessMessage"] = $"Savings account created successfully with Account ID: {savingsAccount.SA_ACCOUNT_ID}";

            // Clear session or keep for further actions
            // Session.Remove("CustomerID");

            return RedirectToAction("Index"); // Back to manager home or wherever you want
        }

        public ActionResult CloseAccount()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CloseAccount(string pan)
        {
            var message = db.CloseAccount(pan);
            ViewBag.Message = message;

            var customer = db1.Customers.FirstOrDefault(c => c.C_PAN == pan);
            ViewBag.Customer = customer;

            return View();
        }

        public ActionResult RemoveEmployee()
        {
            return View();
        }

        [HttpPost]
      
        public ActionResult RemoveEmployee(string eid)
        {
            
            var message = db.RemoveEmployee(eid);
            ViewBag.Message = message;

            
            var employee = db1.Employees.FirstOrDefault(e => e.E_ID == eid);
            ViewBag.Employee = employee;

            return View();
        }
        [HttpGet]
        public ActionResult OpenLoanAccount()
        {
            return View();
        }

        // POST: Check PAN and redirect accordingly
        [HttpPost]
        public ActionResult OpenLoanAccount(string pan)
        {
            if (string.IsNullOrWhiteSpace(pan))
            {
                ViewBag.Message = "Please enter a PAN number.";
                return View();
            }
            db1.Configuration.ProxyCreationEnabled = false;

            var customer = db1.Customers.FirstOrDefault(c => c.C_PAN == pan);

            if (customer != null)
            {
                ViewBag.Customer = customer;
                Session["CustomerID"] = customer.ID;  // Store customer ID in session



                return View();

            }
            else
            {

                ViewBag.Message = "Customer not found. Please register.";
                return View();
                //TempData["PanNumber"] = pan;
                //return RedirectToAction("Register", "Home");
            }
        }

        [HttpGet]
        public ActionResult OpenFDAccount()
        {
            return View();
        }
        [HttpPost]
        public ActionResult OpenFDAccount(string pan)
        {
            if (string.IsNullOrWhiteSpace(pan))
            {
                ViewBag.Message = "Please enter a valid PAN number.";
                return View();
            }

            var customer = db1.Customers.FirstOrDefault(c => c.C_PAN == pan);
            if (customer == null)
            {
                ViewBag.Message = "Customer not found.";
                return View();
            }

            ViewBag.Customer = customer;
            return View();
        }


        // GET: Create Loan Account for existing customer
        [HttpGet]
        public ActionResult CreateLoanAccount()
        {
            if (Session["CustomerID"] == null)
            {
                TempData["ErrorMessage"] = "No customer selected. Please check PAN first.";
                return RedirectToAction("OpenLoanAccount", "Manager");
            }

            int customerId = (int)Session["CustomerID"];
            ViewBag.Customer = db1.Customers.Find(customerId);

            return View();  // View with form to enter loan details
        }

        // POST: Create Loan Account
        [HttpPost]
        public ActionResult CreateLoanAccount(decimal loanAmount, DateTime startDate, int tenure, decimal roi, decimal emi, string status)
        {
            if (Session["CustomerID"] == null)
            {
                TempData["ErrorMessage"] = "No customer selected. Please check PAN first.";
                return RedirectToAction("OpenLoanAccount", "Manager");
            }

            int customerId = (int)Session["CustomerID"];

            if (loanAmount < 10000)
            {
                TempData["ErrorMessage"] = "Loan amount must be at least 10000.";
                return RedirectToAction("CreateLoanAccount", "Manager");
            }
            if (tenure <= 0)
            {
                TempData["ErrorMessage"] = "Tenure must be greater than zero.";
                return RedirectToAction("CreateLoanAccount", "Manager");
            }
            if (roi <= 0)
            {
                TempData["ErrorMessage"] = "Rate of Interest must be greater than zero.";
                return RedirectToAction("CreateLoanAccount", "Manager");
            }
            if (emi <= 0)
            {
                TempData["ErrorMessage"] = "EMI must be greater than zero.";
                return RedirectToAction("CreateLoanAccount", "Manager");
            }
            if (string.IsNullOrWhiteSpace(status))
            {
                status = "Active"; // Default value
            }

            // Create loan account linked to customer
            var loanAccount = new Home_Loan_Account
            {
                C_ID = customerId,
                LOAN_AMOUNT = loanAmount,
                START_DATE = startDate,
                TENURE = tenure,
                LN_ROI = roi,
                EMI = emi,
                STATUS = status
            };

            db1.Home_Loan_Account.Add(loanAccount);
            db1.SaveChanges();

            TempData["SuccessMessage"] = $"Loan account created successfully with Loan ID: {loanAccount.LN_ACCOUNT_ID}";

            // Optionally clear session or keep for further actions
            // Session.Remove("CustomerID");

            return RedirectToAction("ManagerHome", "Manager"); // Redirect to manager home or relevant page
        }


        // GET: Customer Details for Loan (display customer info before loan creation)
        [HttpGet]
        public ActionResult CustomerDetailsForLoan(string pan)
        {
            // Check if the customer exists based on PAN number
            var customer = db1.Customers.FirstOrDefault(c => c.C_PAN == pan);

            if (customer != null)
            {
                ViewBag.Customer = customer;
                Session["CustomerID"] = customer.ID;  // Store customer ID in session for further actions

                // Show customer details and provide the option to create a loan account
                return View(customer);
            }
            else
            {
                TempData["PanNumber"] = pan;  // Store PAN for redirecting to registration if customer doesn't exist
                return RedirectToAction("Register", "Home");  // Redirect to registration page
            }
        }
    }

}



