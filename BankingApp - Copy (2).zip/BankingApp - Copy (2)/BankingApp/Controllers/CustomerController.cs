﻿using BankModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly CustomerService _customerService;

        public CustomerController()
        {
            _customerService = new CustomerService();
        }

        // Dashboard View
        public ActionResult CustomerHome(int? id)
        {
            if (id == null)
            {
                return Content("Error: No account ID provided.");
            }

            var account = _customerService.GetAccountById(id.Value);
            if (account == null)
            {
                return HttpNotFound("Savings account not found.");
            }

            var transactions = _customerService.GetTransactions(account.ID);

            ViewBag.AccountId = account.ID;
            ViewBag.Balance = account.BALANCE;
            ViewBag.Transactions = transactions;

            return View(account);
        }

        // Load Deposit Form (Partial View)
        [HttpGet]
        public PartialViewResult _DepositPartial(int id)
        {
            var account = _customerService.GetAccountById(id);
            return PartialView("_DepositPartial", account); // Partial view: _DepositForm.cshtml
        }

        // Handle Deposit Submission
        [HttpPost]
        public ActionResult Deposit(int id, decimal amount)
        {
            string message = _customerService.Deposit(id, amount);
            TempData["Message"] = message;

            return RedirectToAction("CustomerHome", new { id = id });
        }

        // Load Withdraw Form (Partial View)
        [HttpGet]
        public PartialViewResult _WithdrawPartial(int id)
        {
            var account = _customerService.GetAccountById(id);
            return PartialView("_WithdrawPartial", account); // Partial view: _WithdrawForm.cshtml
        }

        // Handle Withdraw Submission
        [HttpPost]
        public ActionResult Withdraw(int id, decimal amount)
        {
            string message = _customerService.Withdraw(id, amount);
            TempData["Message"] = message;

            return RedirectToAction("CustomerHome", new { id = id });
        }

        // Transactions View (Optional Full View)
        [HttpGet]
        public ActionResult Transactions(int id)
        {
            var transactions = _customerService.GetTransactions(id);
            return View(transactions); // View: Transactions.cshtml
        }
    }
}

    //[HttpPost]
    //public ActionResult Deposit(int customerId, decimal amount)
    //{
    //    string message = _customerService.Deposit(customerId, amount);
    //    ViewBag.Message = message;
    //    ViewBag.CustomerId = customerId;
    //    return View();
    //}

//[HttpGet]
//public ActionResult Withdraw(int id)
//{
//    ViewBag.CustomerId = id;
//    return View();
//}

//[HttpPost]
//public ActionResult Withdraw(int customerId, decimal amount)
//{
//    string message = _customerService.Withdraw(customerId, amount);
//    ViewBag.Message = message;
//    ViewBag.CustomerId = customerId;
//    return View();
//}
