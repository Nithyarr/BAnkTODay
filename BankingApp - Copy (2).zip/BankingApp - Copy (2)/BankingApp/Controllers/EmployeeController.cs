﻿using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class EmployeeController : Controller
    {
        public ActionResult EmployeeHome()
        {
            ViewBag.Message = $"Welcome Employee {Session["Username"]}";
            return View();
        }
    }
}
