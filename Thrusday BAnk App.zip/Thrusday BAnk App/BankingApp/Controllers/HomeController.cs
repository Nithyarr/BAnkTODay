﻿using BankingApp.Models.ViewModel;
using BankModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{

    public class HomeController : Controller
    {

        private readonly AuthService dc = new AuthService();
        private readonly BankDBEntities db1 = new BankDBEntities();
        private readonly ManagerService db;
        private readonly CustomerService cb;

        public HomeController()
        {
            db1 = new BankDBEntities();
            dc = new AuthService();
            db = new ManagerService(db1);
            // Pass the context to ManagerService
            cb = new CustomerService();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var loginResult = dc.Login(model.Username, model.Password);

            if (loginResult.Success)
            {
                Session["Username"] = model.Username;
                Session["Role"] = loginResult.Role;
                Session["ReferenceId"] = loginResult.ReferenceId;

                if (loginResult.Role == "Customer")
                {
                    // Fetch customer name from DB using ReferenceId (customer ID)
                    var customer = db1.Customers.FirstOrDefault(c => c.C_ID == loginResult.ReferenceId);
                    if (customer != null)
                    {
                        Session["CustomerName"] = customer.C_NAME;
                    }

                    return RedirectToAction("CustomerHome", "Customer");
                }
                else if (loginResult.Role == "Employee")
                    return RedirectToAction("EmployeeHome", "Employee");
                else if (loginResult.Role == "Manager")
                    return RedirectToAction("ManagerHome", "Manager");
                else
                    ViewBag.Message = "Unknown user role.";
            }
            else
            {
                ViewBag.Message = loginResult.Message;
            }

            return View(model);
        }


        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult Register(
        //    string userType, string name, string dob, string pan, string mobile,
        //                             string email, decimal? salary, string address, string gender, string password, int? deptId)
        //{
        //    string result;

        //    if (string.IsNullOrEmpty(userType))
        //    {
        //        ViewBag.Message = "Please select a user type.";
        //        return View();
        //    }

        //    if (userType == "Customer")
        //    {
        //        if (!salary.HasValue)
        //        {
        //            ViewBag.Message = "Salary is required for customers.";
        //            return View();
        //        }

        //        result = dc.RegisterCustomer(name, dob, pan, mobile, email, salary.Value, address, gender, password);

        //        // After successful registration, fetch the newly created customer
        //        var newCustomer = db1.Customers.FirstOrDefault(c => c.C_EMAIL == email);
        //        if (newCustomer != null)
        //        {
        //            var savingsAccount = new Savings_Account
        //            {
        //                C_ID = newCustomer.ID,
        //                BALANCE = 1000 // Default minimum balance
        //                               // CREATED_DATE will be set automatically
        //            };

        //            db1.Savings_Account.Add(savingsAccount);
        //            db1.SaveChanges();

        //            result += $" Savings account created with ID: {savingsAccount.SA_ACCOUNT_ID}";
        //        }
        //    }
        //    else if (userType == "Employee")
        //    {
        //        if (!deptId.HasValue)
        //        {
        //            ViewBag.Message = "Department ID is required for employees.";
        //            return View();
        //        }

        //        if (!DateTime.TryParse(dob, out DateTime dobParsed))
        //        {
        //            ViewBag.Message = "Invalid Date of Birth.";
        //            return View();
        //        }

        //        result = dc.RegisterEmployee(name, dobParsed, deptId.Value, pan, mobile, email, address, gender, password);
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Invalid user type selected.";
        //        return View();
        //    }

        //    ViewBag.Message = result;
        //    return View();
        //}

        // Home views for roles
        [HttpPost]
        public ActionResult Register(string userType, RegisterViewModel model, int? deptId)
        {
            if (string.IsNullOrEmpty(userType))
            {
                ModelState.AddModelError("userType", "Please select a user type.");
            }

            // Check ModelState (data annotations validation)
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string result;

            if (userType == "Customer")
            {
                if (!model.C_SALARY.HasValue)
                {
                    ModelState.AddModelError("C_SALARY", "Salary is required for customers.");
                    return View(model);
                }

                result = dc.RegisterCustomer(model.C_NAME, model.C_DOB.ToString("yyyy-MM-dd"), model.C_PAN, model.C_MOBILE, model.C_EMAIL,
                                             model.C_SALARY.Value, model.C_ADDRESS, model.C_GENDER, model.C_PASSWORD);

                var newCustomer = db1.Customers.FirstOrDefault(c => c.C_EMAIL == model.C_EMAIL);
                if (newCustomer != null)
                {
                    var savingsAccount = new Savings_Account
                    {
                        C_ID = newCustomer.ID,
                        BALANCE = 1000 // Default balance
                    };
                    db1.Savings_Account.Add(savingsAccount);
                    db1.SaveChanges();

                    result += $" Savings account created with ID: {savingsAccount.SA_ACCOUNT_ID}";
                }
            }
            else if (userType == "Employee")
            {
                if (!deptId.HasValue)
                {
                    ModelState.AddModelError("deptId", "Department ID is required for employees.");
                    return View(model);
                }

                result = dc.RegisterEmployee(model.C_NAME, model.C_DOB, deptId.Value, model.C_PAN, model.C_MOBILE,
                                             model.C_EMAIL, model.C_ADDRESS, model.C_GENDER, model.C_PASSWORD);
            }
            else
            {
                ModelState.AddModelError("userType", "Invalid user type selected.");
                return View(model);
            }

            ViewBag.Message = result;
            return View();
        }




        public ActionResult EmployeeHome()
        {
            ViewBag.Message = $"Welcome Employee {Session["Username"]}";
            return View();
        }

       
    }
}
