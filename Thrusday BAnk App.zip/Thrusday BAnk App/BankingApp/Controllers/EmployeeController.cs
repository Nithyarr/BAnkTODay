﻿using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class EmployeeController : Controller
    {
       
            public ActionResult Home()
            {
                ViewBag.EmployeeName = "Anagha";
                ViewBag.Department = "Loan Department";
                ViewBag.Message = "Welcome to Employee Dashboard";
                return View();
            }
        
    }
}
