﻿using BankModel;
using BankModel.ViewModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly BankDBEntities _dbContext = new BankDBEntities();
        private readonly CustomerService service = new CustomerService();
        [HttpGet]
        public ActionResult CustomerHome()
        {
            if (Session["CustomerID"] == null)
            {
                return RedirectToAction("Login", "Home"); // not logged in
            }

            int customerId = (int)Session["CustomerID"];

            // Fetch FDs or other customer info if needed
            ViewBag.FDs = service.GetFDAccountsByCustomer(customerId);

            return View();
        }
        [HttpPost]
        public ActionResult CustomerHome(string customerId)
        {
            // Fetch customer from database
            var customer = _dbContext.Customers.FirstOrDefault(c => c.C_ID == customerId);

            if (customer == null)
            {
                return HttpNotFound("Customer not found");
            }

            // Pass the customer object to the view
            ViewBag.Customer = customer;

            return View();
        }


        //[HttpPost]
        //public ActionResult ForecloseFD(int fdId, string confirm)
        //{
        //    if (confirm == "Yes")
        //    {
        //        ViewBag.Message = service.ForecloseFDAccount(fdId);
        //    }
        //    else
        //    {
        //        ViewBag.Message = "FD foreclosure cancelled.";
        //    }

        //    var customer = _dbContext.Customers.FirstOrDefault(c => c.ID == fdId);
        //    ViewBag.Customer = customer;
        //    ViewBag.FDs = service.GetFDAccountsByCustomer(fdId);
        //    return View("CustomerHome");
        //}
        [HttpPost]
        public ActionResult ForecloseFD(int fdId, int customerId, string confirm)
        {
            if (confirm == "Yes")
            {
                ViewBag.Message = service.ForecloseFDAccount(fdId);  // service handles preclosure & transaction
            }
            else
            {
                ViewBag.Message = "FD foreclosure cancelled.";
            }

            // Fetch updated customer and FD list
            var customer = _dbContext.Customers.FirstOrDefault(c => c.ID == customerId);
            ViewBag.Customer = customer;
            ViewBag.FDs = service.GetFDAccountsByCustomer(customerId);

            return View("CustomerHome");
        }
    }
}

    //[HttpPost]
    //public ActionResult Deposit(int customerId, decimal amount)
    //{
    //    string message = _customerService.Deposit(customerId, amount);
    //    ViewBag.Message = message;
    //    ViewBag.CustomerId = customerId;
    //    return View();
    //}

//[HttpGet]
//public ActionResult Withdraw(int id)
//{
//    ViewBag.CustomerId = id;
//    return View();
//}

//[HttpPost]
//public ActionResult Withdraw(int customerId, decimal amount)
//{
//    string message = _customerService.Withdraw(customerId, amount);
//    ViewBag.Message = message;
//    ViewBag.CustomerId = customerId;
//    return View();
//}
